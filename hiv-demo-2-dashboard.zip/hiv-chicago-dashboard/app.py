import json
from copy import deepcopy

import branca.colormap as cm
import folium
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from streamlit_folium import st_folium


st.set_page_config(
    page_title="Chicago HIV Incidence Dashboard",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="collapsed",
)

YEAR_COLUMNS = ["2019", "2020", "2021", "2022", "2023"]
ACCENT_BLUE = "#2563eb"
ACCENT_TEAL = "#0f766e"
ACCENT_GREEN = "#16a34a"
ACCENT_RED = "#dc2626"
ACCENT_AMBER = "#d97706"
BG = "#f8fafc"
PANEL_BG = "#ffffff"
TEXT = "#0f172a"
MUTED = "#64748b"
GENDER_COLORS = {
    "Cisgender Male": "#2563eb",
    "Cisgender Female": "#db2777",
}
RACE_COLORS = {
    "White non-hispanic": "#60a5fa",
    "Black Non Hispanic": "#1d4ed8",
    "Asian or pacific islander non-hispanic": "#14b8a6",
    "Hispanic or Latino": "#f59e0b",
}
AGE_COLORS = {
    "13-19": "#bfdbfe",
    "20-29": "#93c5fd",
    "30-39": "#60a5fa",
    "40-49": "#2563eb",
    "50-59": "#1d4ed8",
    "60+": "#0f172a",
}


st.markdown(
    f"""
<style>
    .stApp {{
        background-color: {BG};
        color: {TEXT};
    }}
    .main .block-container {{
        padding-top: 1.5rem;
        padding-bottom: 2.5rem;
        max-width: 1220px;
    }}
    section[data-testid="stSidebar"] {{
        background-color: {PANEL_BG};
        border-right: 1px solid #e2e8f0;
    }}
    h1, h2, h3, h4, h5, h6, p, label, .stMarkdown {{
        color: {TEXT} !important;
    }}
    .main-header {{
        font-size: 2.35rem;
        color: {TEXT};
        text-align: left;
        margin-bottom: 0.2rem;
        font-weight: 750;
        letter-spacing: 0;
    }}
    .sub-header {{
        font-size: 1.02rem;
        color: {MUTED} !important;
        text-align: left;
        margin-bottom: 1.5rem;
        max-width: 760px;
    }}
    .nav-summary-gap {{
        height: 1.3rem;
    }}
    .summary-section-gap {{
        height: 2rem;
    }}
    .metric-card,
    .insight-box {{
        background: {PANEL_BG};
        padding: 0.9rem;
        border-radius: 8px;
        height: 160px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
        overflow: hidden;
    }}
    .metric-card h3,
    .insight-box h3 {{
        font-size: 0.82rem;
        color: {MUTED} !important;
        margin: 0 0 0.45rem 0;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0;
    }}
    .metric-card .value {{
        font-size: 1.75rem;
        line-height: 1;
        color: {TEXT};
        font-weight: 800;
    }}
    .metric-card .note {{
        font-size: 0.82rem;
        color: {MUTED} !important;
        margin-top: 0.55rem;
        line-height: 1.32;
    }}
    .trend-up {{
        color: {ACCENT_RED};
        font-weight: 800;
    }}
    .trend-down {{
        color: {ACCENT_GREEN};
        font-weight: 800;
    }}
    .trend-flat {{
        color: {MUTED};
        font-weight: 800;
    }}
    .insight-box p {{
        margin: 0;
        color: {MUTED} !important;
        line-height: 1.34;
        font-size: 0.84rem;
    }}
    .selected-community-tile {{
        background: linear-gradient(135deg, #0f172a 0%, #164e63 100%);
        border: 1px solid rgba(20, 184, 166, 0.36);
        border-radius: 8px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.22);
        padding: 1.1rem;
        margin-top: 1rem;
    }}
    .selected-community-tile h3 {{
        margin: 0 0 0.9rem 0;
        font-size: 1.25rem;
        color: #ffffff !important;
    }}
    .selected-community-grid {{
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.9rem;
    }}
    .selected-community-stat {{
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 8px;
        padding: 0.9rem;
    }}
    .selected-community-stat .label {{
        color: #a7f3d0;
        font-size: 0.78rem;
        font-weight: 750;
        text-transform: uppercase;
    }}
    .selected-community-stat .value {{
        color: #ffffff;
        font-size: 1.45rem;
        font-weight: 800;
        line-height: 1.1;
        margin-top: 0.4rem;
    }}
    .selected-community-stat .note {{
        color: #d1fae5;
        font-size: 0.86rem;
        margin-top: 0.4rem;
    }}
    div[data-testid="stDataFrame"] {{
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        overflow: hidden;
    }}
    .community-table {{
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.05);
    }}
    .community-table th {{
        background: #0f172a;
        color: #ffffff;
        font-weight: 750;
        padding: 0.7rem 0.8rem;
        text-align: left;
    }}
    .community-table td {{
        color: {TEXT};
        padding: 0.65rem 0.8rem;
        border-top: 1px solid #e2e8f0;
    }}
    .community-table tr:nth-child(even) td {{
        background: #eff6ff;
    }}
    .stTabs [data-baseweb="tab-list"] {{
        gap: 1.35rem;
        margin-top: 1.65rem;
        margin-bottom: 1.5rem;
    }}
    .stTabs [data-baseweb="tab"] {{
        background: #e2e8f0;
        border-radius: 8px;
        color: {TEXT};
        padding: 0.72rem 1.35rem;
        min-width: 150px;
        justify-content: center;
    }}
    div[role="radiogroup"] {{
        display: grid !important;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 0.9rem;
        margin: 1.6rem 0 0 0;
        background: #ffffff;
        border: 1px solid #dbe3ef;
        border-radius: 10px;
        padding: 0.45rem;
        box-shadow: 0 10px 26px rgba(15, 23, 42, 0.05);
    }}
    div[role="radiogroup"] label {{
        background: #f8fafc;
        border: 1px solid transparent;
        border-radius: 8px;
        padding: 0.82rem 1rem;
        min-width: 0;
        justify-content: center;
        text-align: center;
        transition: all 160ms ease;
    }}
    div[role="radiogroup"] label:hover {{
        background: #e0f2fe;
        border-color: #93c5fd;
    }}
    div[role="radiogroup"] label:has(input:checked) {{
        background: #0f172a;
        border-color: #0f172a;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.16);
    }}
    div[role="radiogroup"] label:has(input:checked) p {{
        color: #ffffff !important;
        font-weight: 750;
    }}
    div[role="radiogroup"] label p {{
        color: {TEXT} !important;
        font-weight: 700;
    }}
    .js-plotly-plot .plotly .main-svg text {{
        fill: {TEXT} !important;
    }}
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_data
def load_data():
    community_raw = pd.read_csv("data/community_hiv_incidence.csv", dtype=str)
    gender = pd.read_csv("data/citywide_gender.csv")
    race = pd.read_csv("data/citywide_race_ethnicity.csv")
    age = pd.read_csv("data/citywide_age.csv")
    with open("data/chicago_community_areas.geojson", encoding="utf-8") as geojson_file:
        geography = json.load(geojson_file)

    community_numeric = community_raw.copy()
    for year in YEAR_COLUMNS:
        community_numeric[year] = pd.to_numeric(community_numeric[year], errors="coerce")
    community_numeric["Map key"] = community_numeric["Place"].str.upper().str.replace("'", "", regex=False)
    community_raw["Map key"] = community_raw["Place"].str.upper().str.replace("'", "", regex=False)

    community_long = community_numeric.melt(
        id_vars=["Place", "Map key"],
        value_vars=YEAR_COLUMNS,
        var_name="Year",
        value_name="HIV incidence",
    )
    community_long["Year"] = community_long["Year"].astype(int)
    return community_raw, community_numeric, community_long, gender, race, age, geography


def plot_template(fig):
    fig.update_layout(
        template="plotly_white",
        paper_bgcolor=PANEL_BG,
        plot_bgcolor=PANEL_BG,
        font=dict(color=TEXT, size=13),
        margin=dict(l=24, r=24, t=54, b=46),
        colorway=[ACCENT_BLUE, ACCENT_TEAL, ACCENT_AMBER, ACCENT_RED],
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.15,
            xanchor="left",
            x=0,
            font=dict(color=TEXT, size=12),
            bgcolor="rgba(255,255,255,0.9)",
        ),
        title=dict(font=dict(color=TEXT, size=17)),
    )
    fig.update_xaxes(gridcolor="#e2e8f0", zerolinecolor="#e2e8f0", color=TEXT, title_font=dict(color=TEXT), tickfont=dict(color=TEXT))
    fig.update_yaxes(gridcolor="#e2e8f0", zerolinecolor="#e2e8f0", color=TEXT, title_font=dict(color=TEXT), tickfont=dict(color=TEXT))
    return fig


def trend_details(current_value, previous_value):
    delta = current_value - previous_value
    if delta > 0:
        return "up", "↑", f"+{delta:,.0f} vs prior year"
    if delta < 0:
        return "down", "↓", f"{delta:,.0f} vs prior year"
    return "flat", "→", "No change vs prior year"


def metric_card(title, value, note, trend=None):
    trend_markup = ""
    if trend:
        direction, symbol, text = trend
        trend_markup = f'<span class="trend-{direction}">{symbol}</span> {text}'
    note_markup = trend_markup or note
    st.markdown(
        f"""
        <div class="metric-card">
            <h3>{title}</h3>
            <div class="value">{value}</div>
            <div class="note">{note_markup}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def insight_box(title, body):
    st.markdown(
        f"""
        <div class="insight-box">
            <h3>{title}</h3>
            <p>{body}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def selected_community_tile(place, max_increase, max_decrease):
    if max_increase is None:
        increase_value = "No increase"
        increase_note = "Across available years"
    else:
        increase_value = f"{int(max_increase['Year'])}"
        increase_note = f"↑ +{int(max_increase['Delta'])} cases"

    if max_decrease is None:
        decrease_value = "No reduction"
        decrease_note = "Across available years"
    else:
        decrease_value = f"{int(max_decrease['Year'])}"
        decrease_note = f"↓ {abs(int(max_decrease['Delta']))} fewer cases"

    st.markdown(
        f"""
        <div class="selected-community-tile">
            <h3>{place}</h3>
            <div class="selected-community-grid">
                <div class="selected-community-stat">
                    <div class="label">Largest Increase</div>
                    <div class="value">{increase_value}</div>
                    <div class="note">{increase_note}</div>
                </div>
                <div class="selected-community-stat">
                    <div class="label">Largest Reduction</div>
                    <div class="value">{decrease_value}</div>
                    <div class="note">{decrease_note}</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


@st.dialog("Community Summary", width="large")
def selected_community_dialog(place, trend_df, max_increase, max_decrease):
    selected_community_tile(place, max_increase, max_decrease)
    fig = community_trend_chart(trend_df, f"{place} 5-Year Trend")
    st.plotly_chart(fig, width='stretch')


def melt_breakdown(df, label):
    value_cols = [c for c in df.columns if c not in ["Year", "Total"]]
    long = df.melt(id_vars="Year", value_vars=value_cols, var_name=label, value_name="Cases")
    return long


def format_change(current_value, previous_value):
    if pd.isna(current_value) or pd.isna(previous_value):
        return "N/A"
    delta = int(current_value - previous_value)
    if delta > 0:
        return f"↑ +{delta}"
    if delta < 0:
        return f"↓ {delta}"
    return "→ 0"


def community_trend_frame(community_raw, map_key):
    selected_row = community_raw.loc[community_raw["Map key"].eq(map_key)].iloc[0]
    trend_df = pd.DataFrame(
        {"Year": [int(year) for year in YEAR_COLUMNS], "Cases": [selected_row[year] for year in YEAR_COLUMNS]}
    )
    trend_df["Cases"] = pd.to_numeric(trend_df["Cases"], errors="coerce")
    trend_df["Delta"] = trend_df["Cases"].diff()
    trend_df["Change"] = [
        "N/A" if index == 0 else format_change(row["Cases"], trend_df.loc[index - 1, "Cases"])
        for index, row in trend_df.iterrows()
    ]
    return trend_df


def trend_extremes(trend_df):
    changes = trend_df.dropna(subset=["Delta"])
    increases = changes.loc[changes["Delta"] > 0]
    decreases = changes.loc[changes["Delta"] < 0]
    max_increase = None if increases.empty else increases.loc[increases["Delta"].idxmax()]
    max_decrease = None if decreases.empty else decreases.loc[decreases["Delta"].idxmin()]
    return max_increase, max_decrease


def community_insight_text(place, trend_df):
    available = trend_df.dropna(subset=["Cases"])
    if available.empty:
        return f"{place} has no available yearly case values in the current dataset."

    latest = available.iloc[-1]
    max_increase, max_decrease = trend_extremes(trend_df)
    direction = "no year-over-year change"
    if not pd.isna(latest["Delta"]):
        if latest["Delta"] > 0:
            direction = f"an increase of {int(latest['Delta'])} cases from the prior year"
        elif latest["Delta"] < 0:
            direction = f"a reduction of {abs(int(latest['Delta']))} cases from the prior year"

    increase_text = "no increase year"
    if max_increase is not None:
        increase_text = f"the largest increase was in {int(max_increase['Year'])} (+{int(max_increase['Delta'])})"

    decrease_text = "no reduction year"
    if max_decrease is not None:
        decrease_text = f"the largest reduction was in {int(max_decrease['Year'])} ({abs(int(max_decrease['Delta']))} fewer)"

    return (
        f"{place} recorded {int(latest['Cases'])} cases in {int(latest['Year'])}, showing {direction}. "
        f"Across the five-year trend, {increase_text}, while {decrease_text}."
    )


def community_trend_chart(trend_df, title, selected_year=None):
    plot_points = trend_df.dropna(subset=["Cases"]).copy()
    plot_points["Change Label"] = plot_points["Delta"].apply(
        lambda value: "" if pd.isna(value) else ("↑" if value > 0 else "↓" if value < 0 else "→")
    )
    fig = px.line(plot_points, x="Year", y="Cases", markers=True, title=title)
    fig.update_traces(line=dict(color=ACCENT_AMBER, width=4), marker=dict(size=10, color=ACCENT_TEAL))
    fig.update_xaxes(type="linear", tickmode="array", tickvals=[int(year) for year in YEAR_COLUMNS])
    for _, row in plot_points.iterrows():
        if row["Change Label"]:
            fig.add_annotation(
                x=row["Year"],
                y=row["Cases"],
                text=row["Change Label"],
                showarrow=False,
                yshift=18,
                font=dict(color=ACCENT_RED if row["Delta"] > 0 else ACCENT_GREEN if row["Delta"] < 0 else MUTED, size=18),
            )

    if selected_year is not None:
        selected_year_int = int(selected_year)
        selected_point = plot_points.loc[plot_points["Year"].eq(selected_year_int)]
        if not selected_point.empty:
            selected_case = int(selected_point["Cases"].iloc[0])
            fig.add_annotation(
                x=selected_year_int,
                y=selected_case,
                text=f"{selected_year}: {selected_case:,}",
                showarrow=True,
                arrowcolor=ACCENT_BLUE,
                arrowwidth=1.5,
                ay=-46,
                font=dict(color=TEXT, size=12),
                bgcolor="#ffffff",
                bordercolor=ACCENT_BLUE,
                borderpad=4,
            )
    plot_template(fig)
    return fig


def build_map_data(community_numeric, geography, year):
    map_values = community_numeric[["Place", "Map key", year]].rename(columns={year: "HIV incidence"})
    boundary_names = pd.DataFrame(
        {
            "Map key": [feature["properties"]["community"] for feature in geography["features"]],
            "Boundary community": [feature["properties"]["community"].title() for feature in geography["features"]],
        }
    )
    map_df = boundary_names.merge(map_values, on="Map key", how="left")
    map_df["Display community"] = map_df["Place"].fillna(map_df["Boundary community"])
    map_df["Status"] = map_df["HIV incidence"].apply(lambda value: "Missing" if pd.isna(value) else "Available")
    centroids = []
    for feature in geography["features"]:
        lon, lat = feature_label_point(feature)
        centroids.append({"Map key": feature["properties"]["community"], "lon": lon, "lat": lat})
    map_df = map_df.merge(pd.DataFrame(centroids), on="Map key", how="left")
    return map_df


def feature_label_point(feature):
    geometry = feature.get("geometry") or {}
    coordinates = geometry.get("coordinates") or []
    polygons = coordinates if geometry.get("type") == "MultiPolygon" else [coordinates]
    rings = []
    for polygon in polygons:
        if polygon:
            rings.append(polygon[0])
    if not rings:
        return None, None

    ring = max(rings, key=lambda points: len(points))
    lon_values = [point[0] for point in ring]
    lat_values = [point[1] for point in ring]
    return (min(lon_values) + max(lon_values)) / 2, (min(lat_values) + max(lat_values)) / 2


def geography_bounds(geography):
    lon_values = []
    lat_values = []
    for feature in geography["features"]:
        geometry = feature.get("geometry") or {}
        coordinates = geometry.get("coordinates") or []
        polygons = coordinates if geometry.get("type") == "MultiPolygon" else [coordinates]
        for polygon in polygons:
            for ring in polygon:
                for lon, lat in ring:
                    lon_values.append(lon)
                    lat_values.append(lat)

    return [[min(lat_values), min(lon_values)], [max(lat_values), max(lon_values)]]


def create_chicago_map(map_df, geography, year):
    chicago_bounds = geography_bounds(geography)
    year_index = YEAR_COLUMNS.index(year)
    previous_year = YEAR_COLUMNS[year_index - 1] if year_index > 0 else None
    value_columns = ["Map key", "Display community", "HIV incidence"]
    map_values = map_df[value_columns].rename(columns={"HIV incidence": "current_value"})
    if previous_year:
        previous_values = community_numeric[["Map key", previous_year]].rename(columns={previous_year: "previous_value"})
        map_values = map_values.merge(previous_values, on="Map key", how="left")
    else:
        map_values["previous_value"] = None

    value_lookup = map_values.set_index("Map key").to_dict("index")
    mapped_geo = deepcopy(geography)
    max_value = max(float(map_values["current_value"].max(skipna=True) or 1), 1)
    color_scale = cm.LinearColormap(
        colors=["#dbeafe", "#93c5fd", "#2563eb", "#1e3a8a"],
        vmin=0,
        vmax=max_value,
        caption=f"HIV incidence, {year}",
    )

    for feature in mapped_geo["features"]:
        key = feature["properties"]["community"]
        values = value_lookup.get(key, {})
        current_value = values.get("current_value")
        previous_value = values.get("previous_value")
        display_name = values.get("Display community") or key.title()

        current_numeric = None if pd.isna(current_value) else float(current_value)
        previous_numeric = None if pd.isna(previous_value) else float(previous_value)
        if current_numeric is None:
            current_display = "No data"
        else:
            current_display = str(int(current_numeric))

        if previous_year is None:
            previous_display = "N/A"
            growth_display = "N/A"
        elif previous_numeric is None:
            previous_display = "No data"
            growth_display = "N/A"
        else:
            previous_display = str(int(previous_numeric))
            if current_numeric is None:
                growth_display = "N/A"
            elif previous_numeric == 0 and current_numeric == 0:
                growth_display = "0.0%"
            elif previous_numeric == 0:
                growth_display = "N/A; previous year was 0"
            else:
                growth_display = f"{((current_numeric - previous_numeric) / previous_numeric) * 100:.1f}%"

        feature["properties"].update(
            {
                "map_key": key,
                "display_community": display_name,
                "current_display": current_display,
                "previous_label": previous_year or "Previous year",
                "previous_display": previous_display,
                "growth_display": growth_display,
                "current_value": current_numeric,
            }
        )

    def style_function(feature):
        value = feature["properties"].get("current_value")
        if value is None:
            return {
                "fillColor": "#64748b",
                "color": "#ffffff",
                "weight": 1,
                "fillOpacity": 0.28,
            }
        return {
            "fillColor": color_scale(value),
            "color": "#ffffff",
            "weight": 1,
            "fillOpacity": 0.74,
        }

    chicago_map = folium.Map(
        location=[41.83, -87.73],
        zoom_start=11,
        min_zoom=10,
        max_zoom=12,
        tiles=None,
        control_scale=False,
        prefer_canvas=True,
        max_bounds=True,
        min_lat=chicago_bounds[0][0],
        max_lat=chicago_bounds[1][0],
        min_lon=chicago_bounds[0][1],
        max_lon=chicago_bounds[1][1],
        zoom_control=False,
        dragging=True,
        scrollWheelZoom=False,
        doubleClickZoom=False,
        boxZoom=False,
        keyboard=False,
        touchZoom=False,
    )
    folium.TileLayer(
        tiles="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
        attr="&copy; OpenStreetMap &copy; CARTO",
        name="Muted city context",
        control=False,
        opacity=0.58,
    ).add_to(chicago_map)
    chicago_map.fit_bounds(chicago_bounds)

    folium.GeoJson(
        mapped_geo,
        name="Community areas",
        style_function=style_function,
        highlight_function=lambda feature: {
            "weight": 3,
            "color": ACCENT_AMBER,
            "fillOpacity": 0.88,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["display_community"],
            aliases=["Community"],
            sticky=True,
            style=(
                "background-color: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; "
                "border-radius: 6px; padding: 6px 10px; font-weight: 700;"
            ),
        ),
        popup=folium.GeoJsonPopup(
            fields=["display_community", "current_display", "previous_display", "growth_display"],
            aliases=["Community", f"{year} incidence", f"{previous_year or 'Previous year'} incidence", "Change"],
            labels=True,
            localize=True,
            style=(
                "background-color: #ffffff; color: #0f172a; border-radius: 10px; "
                "font-family: Arial; font-size: 13px;"
            ),
        ),
    ).add_to(chicago_map)

    color_scale.add_to(chicago_map)
    map_name = chicago_map.get_name()
    chicago_map.get_root().html.add_child(
        folium.Element(
            f"""
            <script>
            const mapContainer = {map_name}.getContainer();
            mapContainer.style.background = "#f8fafc";
            const style = document.createElement("style");
            style.innerHTML = `
                #{map_name} .leaflet-tile-pane {{
                    filter: blur(1.4px) grayscale(0.55) saturate(0.7);
                    opacity: 0.62;
                }}
                #{map_name} .leaflet-overlay-pane {{
                    filter: drop-shadow(0 8px 18px rgba(15, 23, 42, 0.18));
                }}
            `;
            document.head.appendChild(style);
            {map_name}.setView([41.83, -87.73], 11);
            {map_name}.setMaxBounds({chicago_bounds});
            {map_name}.scrollWheelZoom.disable();
            {map_name}.doubleClickZoom.disable();
            {map_name}.boxZoom.disable();
            {map_name}.keyboard.disable();
            if ({map_name}.touchZoom) {{
                {map_name}.touchZoom.disable();
            }}
            {map_name}.on('drag', function() {{
                {map_name}.panInsideBounds({chicago_bounds}, {{ animate: false }});
            }});
            </script>
            """
        )
    )
    return chicago_map


community_raw, community_numeric, community_long, gender, race, age, geography = load_data()
reported_long = community_long.dropna(subset=["HIV incidence"])
latest_year = max(YEAR_COLUMNS)
previous_year = YEAR_COLUMNS[YEAR_COLUMNS.index(latest_year) - 1]
latest_numeric = community_numeric[["Place", latest_year]].dropna(subset=[latest_year])
latest_citywide = int(gender.loc[gender["Year"].eq(int(latest_year)), "Total"].iloc[0])
previous_citywide = int(gender.loc[gender["Year"].eq(int(previous_year)), "Total"].iloc[0])
latest_community_total = int(latest_numeric[latest_year].sum())
top_community_row = latest_numeric.sort_values(latest_year, ascending=False).iloc[0]
top_community = top_community_row["Place"]
top_community_value = int(top_community_row[latest_year])
citywide_trend = trend_details(latest_citywide, previous_citywide)
race_latest = race.loc[race["Year"].eq(int(latest_year))].drop(columns=["Year", "Total"]).T.reset_index()
race_latest.columns = ["Race / Ethnicity", "Cases"]
largest_ethnicity = race_latest.sort_values("Cases", ascending=False).iloc[0]
top_share = (top_community_value / latest_community_total) * 100 if latest_community_total else 0

st.markdown('<h1 class="main-header">Chicago HIV Incidence Dashboard</h1>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-header">A focused view of citywide HIV incidence patterns, demographics, and Chicago community trends.</p>',
    unsafe_allow_html=True,
)

active_section = st.radio(
    "Dashboard section",
    ["Overview", "Chicago Demography", "Community Trends", "Chicago Map"],
    horizontal=True,
    label_visibility="collapsed",
    key="dashboard_section",
)

st.markdown('<div class="nav-summary-gap"></div>', unsafe_allow_html=True)

col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    metric_card("Citywide Total", f"{latest_citywide:,}", latest_year, citywide_trend)
with col2:
    metric_card("Years Tracked", f"{YEAR_COLUMNS[0]}-{latest_year}", "Citywide and community views")
with col3:
    insight_box(
        "Citywide Direction",
        f"{latest_year} is {citywide_trend[2].lower()}, with {latest_citywide:,} total incidence.",
    )
with col4:
    insight_box(
        "Community Concentration",
        f"{top_community} has the highest community value in {latest_year}, representing {top_share:.1f}% of the community total.",
    )
with col5:
    insight_box(
        "Largest Demographic Segment",
        f"{largest_ethnicity['Race / Ethnicity']} is the largest race or ethnicity segment in {latest_year}.",
    )

st.markdown('<div class="summary-section-gap"></div>', unsafe_allow_html=True)

if active_section == "Overview":
    citywide = gender[["Year", "Total"]].copy()
    gender_latest = gender.loc[gender["Year"].eq(int(latest_year))].drop(columns=["Year", "Total"]).T.reset_index()
    gender_latest.columns = ["Category", "Cases"]

    left, right = st.columns([1.15, 1])
    with left:
        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=citywide["Year"],
                y=citywide["Total"],
                mode="lines+markers",
                name="Citywide total",
                line=dict(color=ACCENT_TEAL, width=4),
                marker=dict(size=9),
            )
        )
        fig.update_layout(title="Citywide Trend")
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

    with right:
        fig = px.pie(
            gender_latest,
            names="Category",
            values="Cases",
            hole=0.58,
            color="Category",
            color_discrete_map=GENDER_COLORS,
            title=f"Male vs Female Distribution, {latest_year}",
        )
        fig.update_traces(textposition="outside", textinfo="percent+label", marker=dict(line=dict(color="#ffffff", width=2)))
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

    fig = px.bar(
        race_latest.sort_values("Cases", ascending=True),
        x="Cases",
        y="Race / Ethnicity",
        orientation="h",
        color="Race / Ethnicity",
        color_discrete_map=RACE_COLORS,
        title=f"Ethnicity Division, {latest_year}",
    )
    fig.update_layout(showlegend=False)
    plot_template(fig)
    st.plotly_chart(fig, width='stretch')

if active_section == "Chicago Demography":
    c1, c2 = st.columns(2)

    with c1:
        age_long = melt_breakdown(age, "Age group")
        fig = px.line(
            age_long,
            x="Year",
            y="Cases",
            color="Age group",
            markers=True,
            color_discrete_map=AGE_COLORS,
            title="Age Group Trend",
        )
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

    with c2:
        fig = px.line(gender, x="Year", y="Total", markers=True, title="Citywide Total")
        fig.update_traces(line=dict(color=ACCENT_TEAL, width=4), marker=dict(size=10, color=ACCENT_AMBER))
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

    c3, c4 = st.columns(2)

    with c3:
        race_long = melt_breakdown(race, "Race / Ethnicity")
        fig = px.bar(
            race_long,
            x="Year",
            y="Cases",
            color="Race / Ethnicity",
            color_discrete_map=RACE_COLORS,
            barmode="group",
            title="By Race and Ethnicity",
        )
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

    with c4:
        gender_long = melt_breakdown(gender, "Category")
        fig = px.area(
            gender_long,
            x="Year",
            y="Cases",
            color="Category",
            color_discrete_map=GENDER_COLORS,
            title="By Gender",
        )
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

if active_section == "Community Trends":
    filters_left, filters_right = st.columns([1, 1.4])
    with filters_left:
        selected_year = st.selectbox("Year", YEAR_COLUMNS, index=len(YEAR_COLUMNS) - 1, key="community_year")
    with filters_right:
        places = community_raw["Place"].tolist()
        selected_place = st.selectbox(
            "Community area",
            places,
            index=places.index("Uptown") if "Uptown" in places else 0,
            key="community_area",
        )

    selected_map_key = community_raw.loc[community_raw["Place"].eq(selected_place), "Map key"].iloc[0]
    selected_plot = community_trend_frame(community_raw, selected_map_key)
    selected_table = selected_plot[["Year", "Cases", "Change"]].copy()
    selected_table["Cases"] = selected_table["Cases"].apply(lambda value: "No data" if pd.isna(value) else f"{int(value):,}")

    left, right = st.columns([1.05, 1.35])
    with left:
        st.markdown(selected_table.to_html(index=False, classes="community-table"), unsafe_allow_html=True)
        insight_box("Community Insight", community_insight_text(selected_place, selected_plot))

    with right:
        fig = community_trend_chart(selected_plot, f"{selected_place} Trend", selected_year=selected_year)
        st.plotly_chart(fig, width='stretch')

    if st.toggle("Show heatmap", value=False):
        heatmap_df = community_numeric.set_index("Place")[YEAR_COLUMNS]
        heatmap_hover = heatmap_df.astype(object).apply(
            lambda column: column.map(lambda value: "No data" if pd.isna(value) else f"{int(value):,}")
        )
        fig = px.imshow(
            heatmap_df,
            aspect="auto",
            color_continuous_scale=["#f8fafc", "#dbeafe", ACCENT_BLUE, ACCENT_TEAL, ACCENT_AMBER, ACCENT_RED],
            title="Community Heatmap",
            labels=dict(color="Incidence"),
        )
        fig.update_traces(
            customdata=heatmap_hover.values,
            hovertemplate="Community: %{y}<br>Year: %{x}<br>Cases: %{customdata}<extra></extra>",
        )
        fig.update_layout(
            height=940,
            coloraxis_colorbar=dict(title="Incidence"),
            yaxis=dict(tickfont=dict(size=9), automargin=True),
            xaxis=dict(tickfont=dict(size=12), automargin=True),
        )
        plot_template(fig)
        st.plotly_chart(fig, width='stretch')

if active_section == "Chicago Map":
    map_df = build_map_data(community_numeric, geography, latest_year)
    map_fig = create_chicago_map(map_df, geography, latest_year)
    map_result = st_folium(
        map_fig,
        height=760,
        returned_objects=["last_active_drawing"],
        use_container_width=True,
        center=(41.83, -87.73),
        zoom=11,
        key="chicago_map_v2",
    )
    active_drawing = (map_result or {}).get("last_active_drawing") or {}
    clicked_properties = active_drawing.get("properties", {})
    clicked_map_key = clicked_properties.get("map_key")
    if clicked_map_key in set(community_raw["Map key"]):
        clicked_place = community_raw.loc[community_raw["Map key"].eq(clicked_map_key), "Place"].iloc[0]
        map_trend = community_trend_frame(community_raw, clicked_map_key)
        max_increase, max_decrease = trend_extremes(map_trend)

        selected_community_dialog(clicked_place, map_trend, max_increase, max_decrease)
    else:
        insight_box("Select a Community", "Choose a community area on the Chicago map to open its trend and increase/reduction summary.")
